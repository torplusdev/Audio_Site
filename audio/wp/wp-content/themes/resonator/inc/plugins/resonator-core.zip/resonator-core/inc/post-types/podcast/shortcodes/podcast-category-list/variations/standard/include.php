<?php

include_once RESONATOR_CORE_CPT_PATH . '/podcast/shortcodes/podcast-category-list/variations/standard/helper.php';