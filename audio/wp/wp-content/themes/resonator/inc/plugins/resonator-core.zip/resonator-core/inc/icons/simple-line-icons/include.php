<?php

include_once RESONATOR_CORE_INC_PATH . '/icons/simple-line-icons/simple-line-icons.php';