<?php

include_once RESONATOR_CORE_INC_PATH . '/icons/elegant-icons/elegant-icons.php';