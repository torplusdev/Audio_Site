<?php

include_once RESONATOR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/instagram-list.php';