<?php

include_once RESONATOR_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';