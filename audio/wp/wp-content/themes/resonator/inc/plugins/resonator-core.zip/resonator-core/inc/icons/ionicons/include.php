<?php

include_once RESONATOR_CORE_INC_PATH . '/icons/ionicons/ionicons.php';