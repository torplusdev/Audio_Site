<?php

include_once RESONATOR_CORE_INC_PATH . '/opener-icon/helper.php';