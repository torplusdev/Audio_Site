<?php

include_once RESONATOR_CORE_INC_PATH . '/icons/material-icons/material-icons.php';