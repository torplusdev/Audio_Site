<?php

include_once RESONATOR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';