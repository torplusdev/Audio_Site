<?php

include_once RESONATOR_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/twitter-list.php';