(function ($) {
	"use strict";
	
	qodefCore.shortcodes.resonator_core_clients_list = {};
	qodefCore.shortcodes.resonator_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);