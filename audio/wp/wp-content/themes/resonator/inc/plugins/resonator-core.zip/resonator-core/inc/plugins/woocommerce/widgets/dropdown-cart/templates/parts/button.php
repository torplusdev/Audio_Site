<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link">
		<span class="qodef-m-text"><?php esc_html_e( 'View cart', 'resonator-core' ); ?></span>
		<?php echo qode_framework_icons()-> render_icon('ion-ios-arrow-round-forward', 'ionicons' ); ?>
	</a>
</div>