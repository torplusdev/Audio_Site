(function ($) {
    "use strict";
    
	qodefCore.shortcodes.resonator_core_product_categories_list = {};
	qodefCore.shortcodes.resonator_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.resonator_core_product_categories_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);