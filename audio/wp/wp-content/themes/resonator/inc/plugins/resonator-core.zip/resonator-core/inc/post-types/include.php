<?php

include_once RESONATOR_CORE_CPT_PATH . '/post-types.php';