<?php

if ( ! empty ( $show_next_up ) && 'yes' === $show_next_up ) { ?>
	<span class="qodef-next-text"> <?php esc_html_e('Next up:','resonator-core'); ?></span>
<?php
}
