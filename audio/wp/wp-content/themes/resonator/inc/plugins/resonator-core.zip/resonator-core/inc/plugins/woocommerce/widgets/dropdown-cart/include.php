<?php

include_once RESONATOR_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/dropdown-cart.php';