<?php

include_once RESONATOR_CORE_INC_PATH . '/content/helper.php';