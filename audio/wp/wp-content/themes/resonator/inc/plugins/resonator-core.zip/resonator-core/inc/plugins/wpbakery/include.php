<?php

include_once RESONATOR_CORE_PLUGINS_PATH . '/wpbakery/helper.php';