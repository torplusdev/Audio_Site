<?php

include_once RESONATOR_CORE_CPT_PATH . '/podcast/shortcodes/podcast-list/variations/info-right/info-right.php';