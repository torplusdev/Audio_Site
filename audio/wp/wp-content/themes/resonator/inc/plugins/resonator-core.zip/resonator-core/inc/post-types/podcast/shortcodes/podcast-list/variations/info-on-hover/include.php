<?php

include_once RESONATOR_CORE_CPT_PATH . '/podcast/shortcodes/podcast-list/variations/info-on-hover/info-on-hover.php';
include_once RESONATOR_CORE_CPT_PATH . '/podcast/shortcodes/podcast-list/variations/info-on-hover/hover-animations/include.php';