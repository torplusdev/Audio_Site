<?php

include_once RESONATOR_CORE_CPT_PATH . '/podcast/shortcodes/podcast-list/variations/info-on-hover/hover-animations/fade-in/helper.php';