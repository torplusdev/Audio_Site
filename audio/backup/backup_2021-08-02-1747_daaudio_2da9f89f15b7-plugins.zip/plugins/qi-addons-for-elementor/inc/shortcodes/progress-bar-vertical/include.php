<?php

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/progress-bar-vertical/class-qiaddonsforelementor-progress-bar-vertical-shortcode.php';
