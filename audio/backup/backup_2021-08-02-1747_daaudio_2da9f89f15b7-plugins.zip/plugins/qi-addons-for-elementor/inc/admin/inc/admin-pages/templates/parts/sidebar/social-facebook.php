<div class="qodef-social-box">
	<a href="https://www.facebook.com/QodeInteractive/" target="_blank">
		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="13px" height="25px" viewBox="-12.952 3.221 13 25" enable-background="new -12.952 3.221 13 25" xml:space="preserve">
				<g>
					<path fill="#CACACA" d="M-9.702,15.721h-3.25v-4.297h3.25V8.884c0-1.92,0.372-3.344,1.117-4.272
						C-7.84,3.684-6.452,3.221-4.42,3.221h4.469v4.296h-3.098c-0.779,0-1.27,0.13-1.473,0.391c-0.203,0.26-0.305,0.716-0.305,1.367
						v2.148h4.875l-0.457,4.297h-4.418v12.5h-4.875V15.721z"/>
				</g>
			</svg>
		<span><?php esc_html_e( 'Facebook', 'qi-addons-for-elementor' ); ?></span>
	</a>
</div>
