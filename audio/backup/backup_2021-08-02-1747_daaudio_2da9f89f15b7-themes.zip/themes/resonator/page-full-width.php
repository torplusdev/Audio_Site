<?php
/*
Template Name: Qode Full Width Template
*/

get_header();

// Include content template
resonator_template_part( 'content', 'templates/content' );

get_footer();
