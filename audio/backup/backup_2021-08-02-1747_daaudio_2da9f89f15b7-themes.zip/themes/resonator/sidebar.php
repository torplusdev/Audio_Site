<?php if ( is_active_sidebar( resonator_get_sidebar_name() ) ) { ?>
	<aside id="qodef-page-sidebar">
		<?php dynamic_sidebar( resonator_get_sidebar_name() ); ?>
	</aside>
<?php } ?>
