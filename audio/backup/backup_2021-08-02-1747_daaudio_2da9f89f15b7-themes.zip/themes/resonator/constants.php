<?php

define( 'RESONATOR_ROOT', get_template_directory_uri() );
define( 'RESONATOR_ROOT_DIR', get_template_directory() );
define( 'RESONATOR_ASSETS_ROOT', RESONATOR_ROOT . '/assets' );
define( 'RESONATOR_ASSETS_ROOT_DIR', RESONATOR_ROOT_DIR . '/assets' );
define( 'RESONATOR_ASSETS_CSS_ROOT', RESONATOR_ASSETS_ROOT . '/css' );
define( 'RESONATOR_ASSETS_CSS_ROOT_DIR', RESONATOR_ASSETS_ROOT_DIR . '/css' );
define( 'RESONATOR_ASSETS_JS_ROOT', RESONATOR_ASSETS_ROOT . '/js' );
define( 'RESONATOR_ASSETS_JS_ROOT_DIR', RESONATOR_ASSETS_ROOT_DIR . '/js' );
define( 'RESONATOR_INC_ROOT', RESONATOR_ROOT . '/inc' );
define( 'RESONATOR_INC_ROOT_DIR', RESONATOR_ROOT_DIR . '/inc' );
