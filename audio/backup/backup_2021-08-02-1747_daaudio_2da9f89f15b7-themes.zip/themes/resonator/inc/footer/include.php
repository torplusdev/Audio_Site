<?php

include_once RESONATOR_INC_ROOT_DIR . '/footer/helper.php';
