<?php

// Include page footer top area
resonator_template_part( 'footer', 'templates/parts/footer-top-area' );

// Include page footer bottom area
resonator_template_part( 'footer', 'templates/parts/footer-bottom-area' );
