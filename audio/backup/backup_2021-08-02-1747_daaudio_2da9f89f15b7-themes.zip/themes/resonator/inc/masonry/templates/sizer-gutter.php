<?php if ( 'masonry' === $params ) { ?>
	<div class="qodef-grid-masonry-sizer"></div>
	<div class="qodef-grid-masonry-gutter"></div>
<?php } ?>
