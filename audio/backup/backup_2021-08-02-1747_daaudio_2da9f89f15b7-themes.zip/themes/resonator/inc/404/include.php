<?php

include_once RESONATOR_INC_ROOT_DIR . '/404/helper.php';
