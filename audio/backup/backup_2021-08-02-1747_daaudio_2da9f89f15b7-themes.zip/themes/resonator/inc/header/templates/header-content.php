<?php

// Include logo
resonator_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
resonator_template_part( 'header', 'templates/parts/navigation' );
