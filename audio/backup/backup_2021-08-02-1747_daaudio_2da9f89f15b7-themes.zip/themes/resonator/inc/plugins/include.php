<?php

require_once RESONATOR_INC_ROOT_DIR . '/plugins/class-tgm-plugin-activation.php';
include_once RESONATOR_INC_ROOT_DIR . '/plugins/plugins-activation.php';
