<?php

include_once RESONATOR_INC_ROOT_DIR . '/rest/class-resonatortheme-rest-api.php';
