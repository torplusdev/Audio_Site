<?php

// Include mobile logo
resonator_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
resonator_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
resonator_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );
