<a class="qodef-mobile-header-opener" href="#">
	<span class="qodef--initial">
		<span class="qodef-m-lines">
			<span class="qodef-m-line qodef--1">
				<span class="qodef-m-dot qodef--1"></span>
				<span class="qodef-m-dot qodef--2"></span>
				<span class="qodef-m-dot qodef--3"></span>
			 </span>
			<span class="qodef-m-line qodef--2">
				<span class="qodef-m-dot qodef--1"></span>
				<span class="qodef-m-dot qodef--2"></span>
				<span class="qodef-m-dot qodef--3"></span>
			 </span>
			<span class="qodef-m-line qodef--3">
				<span class="qodef-m-dot qodef--1"></span>
				<span class="qodef-m-dot qodef--2"></span>
				<span class="qodef-m-dot qodef--3"></span>
			 </span>
		</span>
	</span>
</a>
