<?php

include_once RESONATOR_INC_ROOT_DIR . '/content/helper.php';
