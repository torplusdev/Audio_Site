<?php

include_once RESONATOR_INC_ROOT_DIR . '/search/helper.php';
