<?php

include_once RESONATOR_INC_ROOT_DIR . '/woocommerce/class-resonatortheme-woocommerce.php';
