<?php

include_once RESONATOR_INC_ROOT_DIR . '/welcome/class-resonatortheme-welcome-page.php';
