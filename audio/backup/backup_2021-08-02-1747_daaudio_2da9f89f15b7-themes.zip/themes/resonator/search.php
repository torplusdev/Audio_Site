<?php

get_header();

// Include content template
resonator_template_part( 'content', 'templates/content', 'search' );

get_footer();
